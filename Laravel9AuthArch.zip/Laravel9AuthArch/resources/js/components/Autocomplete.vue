<template>
    <div>
        <input type="text" placeholder="Start Typing" v-model="query" v-on:keyup="autoComplete" class="form-control">
        <div class="panel-footer" v-if="results.length">
            <ul class="list-group">
                <li class="list-group-item" v-for="result in results" v-on:click="selectDataValue(result)">
                   {{ result.flag }} {{ result.name }}
                </li>
            </ul>
        </div>
    </div>
</template>
<script>
export default{
    data(){
        return {
            query: '',
            results: [],
            phoneCode: "###"
        }
    },
    methods: {
        autoComplete() {
            this.results = [];
            if(this.query.length > 2){
                axios.get('/api/search',{params: {query: this.query}}).then(response => {
                    this.results = response.data;
                });
            }
        },
        selectDataValue(data) {
            this.query = `${data.flag} ${data.name}`;
            this.results = [];
        }
    }
}
</script>
