<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <form @submit.prevent="submitForm">
                    <div class="card-body">
                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">Full Name</label>
                            <div class="col-md-6">
                                <input
                                    id="name"
                                    type="text"
                                    class="form-control"
                                    placeholder="Full Name"
                                    name="name"
                                    v-model="fullName"
                                    required autocomplete="name" autofocus
                                >
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">Country</label>

                            <div class="col-md-6 relative">
                                <input type="text" placeholder="Start Typing" v-model="query" v-on:keyup="autoComplete" class="form-control">
                                <div class="panel-footer" v-if="results.length">
                                    <ul class="list-group">
                                        <li class="list-group-item" v-for="result in results" v-on:click="selectDataValue(result)">
                                            {{ result.flag }} {{ result.name }}
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">Phone Number</label>
                            <div class="col-md-6">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">{{this.phoneCode}}</span>
                                    </div>
                                    <input
                                        v-mask="'## ###-##-##'"
                                        v-model="phone"
                                        id="phone"
                                        type="text"
                                        class="form-control"
                                        placeholder="Phone Number"
                                        name="phone"
                                        required autocomplete="Phone Number" autofocus
                                    >
                                </div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">Email</label>

                            <div class="col-md-6">
                                <input
                                    id="email"
                                    type="text"
                                    class="form-control"
                                    placeholder="Email"
                                    name="email"
                                    v-model="email"
                                    v-on:keydown="handleError('email')"
                                    required autocomplete="Phone Number" autofocus
                                >
                                <span class="error">{{errors.email}}</span>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <button type="submit" class="btn">Register</button>
                            </div>
                        </div>
                    </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mask } from 'vue-the-mask'

export default {
    methods: {
        autoComplete() {
            this.results = [];
            if(this.query.length >= 2){
                axios.get('/api/search',{params: {query: this.query}}).then(response => {
                    this.results = response.data;
                });
            }
        },
        selectDataValue(data) {
            this.query = `${data.flag} ${data.name}`;
            this.phoneCode = data.idd;
            this.countryId = data.id;
            this.results = [];
        },
        handleError( field) {
            this.errors[field] = '';
        },
        async submitForm() {
            const errors = {};
            if (!this.email) {
                errors.email = 'Email is required';
            } else if (!/^[^@]+@\w+(\.\w+)+\w$/.test(this.email)) {
                errors.email = 'Invalid email';
            }
            if (Object.keys(errors).length > 0) {
                this.errors = errors;
                return;
            } else {
                this.errors = {};
                axios.post('/api/submit-registration',{params: {
                    fullName: this.fullName,
                    phone: this.phone,
                    phoneCode: this.phoneCode,
                    email: this.email,
                    countryId: this.countryId
                }}).then(response => {
                    this.results = response.data;
                    this.$router.push(route.query.redirectedFrom || '/confirm-registration')
                });
            }
        }
    },
    data () {
        return {
            phoneCode: '###',
            fullName: '',
            email: '',
            phone: '',
            query: '',
            results: [],
            errors: {},
            countryId: ''
        }
    },
    directives: { mask },
    mounted() {
    },
    computed: {
        isValidEmail() {
            return /^[^@]+@\w+(\.\w+)+\w$/.test(this.email);
        }
    },
}
</script>
