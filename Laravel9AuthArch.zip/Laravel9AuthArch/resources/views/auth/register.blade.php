@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <register-component></register-component>
    </div>
</div>
@endsection
