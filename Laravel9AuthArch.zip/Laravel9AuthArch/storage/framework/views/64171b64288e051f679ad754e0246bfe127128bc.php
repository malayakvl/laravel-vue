<?php echo e($slot); ?>

<?php /**PATH /Users/viktoriakorogod/WEB/Laravel9Auth/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>